clc;
clearvars;
close all;

load("compEx1data.mat") %loading data

%%
% constructing normalization matrices for two images
mean1=mean(x{1}, 2);
std1=std(x{1}, 0, 2);
N1 = [1/std1(1), 0, -mean1(1)/std1(1);
      0, 1/std1(2), -mean1(2)/std1(2);
      0, 0, 1];

mean2=mean(x{2}, 2);
std2= std(x{2}, 0, 2);
N2 = [1/std2(1), 0, -mean2(1)/std2(1);
      0, 1/std2(2), -mean2(2)/std2(2);
      0, 0, 1];

% comment out these two lines for un-normalized case
%N1 = eye(3); 
%N2 = eye(3);
% normalizing points
x1n = N1*x{1};
x2n = N2*x{2};

%%
% constructing the matrix M
M = zeros(size(x1n, 2), 9);
for i = 1:size(x1n, 2)
% Computes a 3x3 matrix containing all multiplications
% of coordinates from x1n(:, i) and x2n(:, i).
    xx = x2n(:, i)*x1n(:, i)'; 
    M(i,:) = xx(:)'; % Reshapes the matrix above and adds to the M matrix
end
[U,S,V] = svd(M);
disp('The minimum singular value:');
disp(min(diag(S))); % we see that the smallest eigenvalue is close to 0

%%
% Forms an F - matrix from the solution V of the least squares problem
Fn = reshape(V(:, end), [3 3]);
disp('Deternimant of Fn:');
disp(det(Fn)); % is close to 0

[U1,S1,V1] = svd(Fn);
F = U1*diag([S1(1,1), S1(2,2), 0]) * V1';
disp('Deternimant of F:');
disp(det(F)); % is even closer to 0

%%
% Computes and plots all the epipolar constraints (should be roughly 0)
figure
plot(diag(x2n'*Fn*x1n));

%%
% computing the un-normalized fundamental matrix F
F = N2'*F*N1;
F = F./F(3, 3);
% Computes the epipolar lines
l = F*x{1};

%%
im2 = imread("kronan2.JPG");
% Generate random indices to pick 20 points
num_points_to_pick = 20;
num_total_points = size(x{2}, 2); % Get the total number of points

% Make sure we pick unique points, hence using randperm
random_indices = randperm(num_total_points, num_points_to_pick);

% Extract the 20 randomly selected points from x{2}
random_points = x{2}(:, random_indices);

%plot image, random 20 points and epipolar lines in one figure.
figure
imshow(im2);
hold on
plot(random_points(1,:), random_points(2,:), '*', 'Color', 'red');
hold on
rital(l(:,random_indices));
hold off

%%
% Makes sure that the line has a unit normal
% (makes the distance formula easier)
l = l./sqrt(repmat(l(1, :).^2 + l(2, :).^2, [3 1]));
% Computes all the the distances between the points
% and there corresponding lines, and plots in a histogram
figure
hist(abs(sum(l.*x{2})), 100);
% 0.36123 with normalization, 0.48784 without normalization.
fprintf("The mean distance is: %.5f\n", mean(abs(sum(l.*x{2}))))
