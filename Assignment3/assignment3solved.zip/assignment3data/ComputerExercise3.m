clc;
clearvars;
close all;

%loading data
load("compEx1data.mat")
load("compEx3data.mat") 

%%
% normalizing image points by multipying with inverse of K
x1n = K\x{1}; % alternative for inv(K)*x{1}
x2n = K\x{2};

%%
% constructing M matrix
M = zeros(size(x1n, 2), 9);
for i = 1:size(x1n, 2)
% Computes a 3x3 matrix containing all multiplications
% of coordinates from x1n(:, i) and x2n(:, i).
    xx = x2n(:, i)*x1n(:, i)'; 
    M(i,:) = xx(:)'; % Reshapes the matrix above and adds to the M matrix
end
[Un,Sn,Vn] = svd(M);
disp('The minimum singular value:');
disp(min(diag(Sn))); % we see that the smallest eigenvalue is close to 0

%%
% the Essential matrix
En = reshape(Vn(:, end), [3 3]);
% Creates a valid essential matrix from an approximate solution.
% Note: Computing svd on E may still give U and V that does not fulfill
% det(U*V') = 1 since the svd is not unique.
% So don’t recompute the svd after this step.
[U,S,V] = svd(En);
if det(U*V')>0
    E = U*diag([1 1 0])* V';
else
    V = -V;
    E = U*diag([1 1 0])* V';
end
E = E./E(3, 3);

%%
% Computes and plots all the epipolar constraints (should be roughly 0)
figure
plot(diag(x2n'*En*x1n));

%%
%Compute the fundamental matrix for the un-normalized coordinate system 
% from the essential matrix 
F = inv(K)'*E*inv(K);
% Computes the epipolar lines
l = F*x{1};

%%
im2 = imread("kronan2.JPG");
% Generate random indices to pick 20 points
num_points_to_pick = 20;
num_total_points = size(x{2}, 2); % Get the total number of points

% Make sure we pick unique points, hence using randperm
random_indices = randperm(num_total_points, num_points_to_pick);

% Extract the 20 randomly selected points from x{2}
random_points = x{2}(:, random_indices);

%plot image, random 20 points and epipolar lines in one figure.
figure
imshow(im2);
hold on
plot(random_points(1,:), random_points(2,:), '*', 'Color', 'red');
hold on
rital(l(:,random_indices));
hold off

%%
% Makes sure that the line has a unit normal
% (makes the distance formula easier)
l = l./sqrt(repmat(l(1, :).^2 + l(2, :).^2, [3 1]));
% Computes all the the distances between the points
% and there corresponding lines , and plots in a histogram
figure
hist(abs(sum(l.*x{2})),100);
%mean distance is 32.0838.
disp('The mean distance is:');
disp(mean(abs(sum(l.*x{2}))));
