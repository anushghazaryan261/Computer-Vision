function res = pflat(x)
    last_row = x(end,:); % Extracts the last row of x
    res = x(:,:); %copying values of the input matrix to the resulting one
    res = res./last_row; %dividing by last elements from last row
end