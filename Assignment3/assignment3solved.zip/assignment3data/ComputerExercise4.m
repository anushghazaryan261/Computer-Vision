% run after executing comouter exercise 3
W = [0, -1, 0; 1, 0, 0; 0, 0, 1];
u3 = U(:, end); %last column of U
% the four camera solutions
P21 = [U*W*V', u3];
P22 = [U*W*V', -u3];
P23 = [U*W'*V', u3];
P24 = [U*W'*V', -u3];
% P1 = [I 0]
P1 = [eye(3), zeros(3,1)];

%%
% constructing 3D points
n = length(x1n);
X1 = zeros(4, n);
zero_mat = zeros(3,1);

% Loop through each point
for i = 1:n
    % Construct matrix M
    M = [P1, -x1n(:,i), zero_mat; P21, zero_mat, -x2n(:,i)];

    % Compute SVD of M
    [U, S, V] = svd(M);

    % Solution vector v is the column of V corresponding to the smallest singular value
    X1(:, i) = reshape(V(1:4,end),1,4);
end

% Reshape X to 3D points
X1 = X1(1:3, :) ./ repmat(X1(4, :), [3, 1]);
% add homogeneous coordinates
X1(4,:) = 1;

%%
% determining how many points are in front of the cameras
nX1P21 = 0;
for i = 1:n
    if(depth(P1, X1(:, i)) > 0 && depth(P21, X1(:, i)) > 0)
        nX1P21 = nX1P21 + 1;
    end
end
% 0 points are in front of P1 and P21

%%
% constructing 3D points
X2 = zeros(4, size(x{1}, 2));

% Loop through each point
for i = 1:size(x1n, 2)
    % Construct matrix M
    M = [P1, -x1n(:,i), zero_mat; P22, zero_mat, -x2n(:,i)];

    % Compute SVD of M
    [U, S, V] = svd(M);

    % Solution vector v is the column of V corresponding to the smallest singular value
    X2(:, i) = reshape(V(1:4,end),1,4)';
end

% Reshape X to 3D points
X2 = X2(1:3, :) ./ repmat(X2(4, :), [3, 1]);
% add homogeneous coordinates
X2(4,:) = 1;

%%
% determining how many points are in front of the cameras
nX2P22 = 0;
for i = 1:size(X2,2)
    if(depth(P1, X2(:, i)) > 0 && depth(P22, X2(:, i)) > 0)
        nX2P22 = nX2P22 + 1;
    end
end
% 2008 points are in front of P1 and P22, gives the best solution

%%
% constructing 3D points
X3 = zeros(4, size(x{1}, 2));

% Loop through each point
for i = 1:size(x1n, 2)
    % Construct matrix M
    M = [P1, -x1n(:,i), zero_mat; P23, zero_mat, -x2n(:,i)];

    % Compute SVD of M
    [U, S, V] = svd(M);

    % Solution vector v is the column of V corresponding to the smallest singular value
    X3(:, i) = reshape(V(1:4,end),1,4);
end

% Reshape X to 3D points
X3 = X3(1:3, :) ./ repmat(X3(4, :), [3, 1]);
% add homogeneous coordinates
X3(4,:) = 1;

%%
% determining how many points are in front of the cameras
nX3P23 = 0;
for i = 1:size(X3,2)
    if(depth(P1, X3(:, i)) > 0 && depth(P23, X3(:, i)) > 0)
        nX3P23 = nX3P23 + 1;
    end
end
% 0 points are in front of P1 and P23

%%
% constructing 3D points
X4 = zeros(4, size(x{1}, 2));

% Loop through each point
for i = 1:size(x1n, 2)
    % Construct matrix M
    M = [P1, -x1n(:,i), zero_mat; P24, zero_mat, -x2n(:,i)];

    % Compute SVD of M
    [U, S, V] = svd(M);

    % Solution vector v is the column of V corresponding to the smallest singular value
    X4(:, i) = reshape(V(1:4,end),1,4);
end

% Reshape X to 3D points
X4 = X4(1:3, :) ./ repmat(X4(4, :), [3, 1]);
% add homogeneous coordinates
X4(4,:) = 1;

%%
% determining how many points are in front of the cameras
nX4P24 = 0;
for i = 1:size(X4,2)
    if(depth(P1, X4(:, i)) > 0 && depth(P24, X4(:, i)) > 0)
        nX4P24 = nX4P24 + 1;
    end
end
% 0 points are in front of P1 and P24
% we get that P22 is the right solution

%%
%Plotting the image, the projected points, and the image points in the same figure
figure
imshow(im2);
hold on;
% Plots a '*' at each point coordinate
plot(x{2}(1,:), x{2}(2,:), '*');
hold on;
% divide by the third coordinate
xproj = pflat(K*P22*X2);
% Plots a red ’o ’ at each visible point in xproj
plot(xproj(1,:), xproj(2,:), 'ro');
hold off;
%%
% plotting the 3D points in 3D plot
figure
plot3(X2(1,:), X2(2,:), X2(3,:), '.', 'MarkerSize', 2);
hold on;
plotcams({P1, P22});
hold off;