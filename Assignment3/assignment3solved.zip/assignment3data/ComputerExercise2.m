% F is the Fundamental Matrix from Computer Exercise 1
e2 = pflat(null(F')); % Computes the epipole
% Constructs the cross product matrix
e2x = [0, -e2(3), e2(2); e2(3), 0, -e2(1); -e2(2), e2(1), 0];

%%
% computing camera matrices
P1 = [eye(3), zeros(3,1)];
P2 = [e2x*F, e2];

%%
% constructing 3D points
X = zeros(4, size(x{1}, 2));
zero_mat = zeros(3,1);

% Loop through each point
for i = 1:size(x1n, 2)
    % Construct matrix M
    M = [P1, -x{1}(:,i), zero_mat; P2, zero_mat, -x{2}(:,i)];

    % Compute SVD of M
    [U, S, V] = svd(M);

    % Solution vector v is the column of V corresponding to the smallest singular value
    X(:, i) = reshape(V(1:4,end),1,4)';
end

% Reshape X to 3D points
X = X(1:3, :) ./ repmat(X(4, :), [3, 1]);
% add homogeneous coordinates
X(4,:) = 1;

%%
%Plotting the image, the projected points, and the image points in the same figure
figure
imshow(im2);
hold on;
% Plots a '*' at each point coordinate
plot(x{2}(1,:), x{2}(2,:), '*');
hold on;
% divide by the third coordinate
xproj = pflat(P2*X);
% Plots a red ’o ’ at each visible point in xproj
plot(xproj(1,:), xproj(2,:), 'ro');
hold off;

%%
% plotting the 3D points in 3D plot
figure
plot3(X(1,:), X(2,:), X(3,:), '.', 'MarkerSize', 2);
