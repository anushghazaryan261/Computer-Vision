clc;
clearvars;
close all;

img1 = imread("compEx4im1.JPG");
img2 = imread("compEx4im2.JPG");

load("compEx4.mat");

% Computing camera matrices for im1 and im2 respectively
P1 = K * [R1, t1];
P2 = K * [R2, t2];

% Compute camera centers of the cameras
C1 = pflat(null(P1));% computes the nullspace of P1
C2 = pflat(null(P2));% computes the nullspace of P1

% Compute principal axes of the cameras
v1 = P1(3, 1:3); % extracts elements P31, P32 and P33.
v2 = P2(3, 1:3); % extracts elements P31, P32 and P33.

U_flat = pflat(U);

figure
plot3(U_flat(1,:), U_flat(2,:), U_flat(3,:), '.', 'Color', 'b');
hold on;
plot3(C1(1,:), C1(2,:), C1(3,:), '.', 'Color', 'g');
hold on;
plot3(C2(1,:), C2(2,:), C2(3,:), '.', 'Color', 'r');
hold on;
quiver3(C1(1), C1(2), C1(3), ...
        v1(1), v1(2), v1(3), 1, 'Color', 'g');
hold on;
quiver3(C2(1), C2(2), C2(3), ...
        v2(1), v2(2), v2(3), 1, 'Color', 'r');
hold off;

figure
proj1 = pflat(P1 * U_flat);
proj2 = pflat(P2 * U_flat);
subplot(1,2,1)
imshow(img1);
title('Image 1')
hold on;
scatter(proj1(1,:), proj1(2,:), 5, 'r', 'filled');
hold on;
subplot(1,2,2)
imshow(img2);
title('Image 2')
hold on;
scatter(proj2(1,:), proj2(2,:), 5, 'r', 'filled');
hold off;