clc;
clearvars;
close all;

img = imread("compEx2.JPG"); % read the image
imshow(img);
hold on;

load("compEx2.mat"); %load compEx2.mat file

% Defining the coordinates of the points we want to plot
p1x = p1(1,:);
p1y = p1(2,:);

p2x = p2(1,:);
p2y = p2(2,:);

p3x = p3(1,:);
p3y = p3(2,:);

% Plot points from p1 on the image
scatter(p1x, p1y, 50, 'r', 'filled'); % 50 is the marker size, 'r' is the color, 'filled' fills the markers
hold on;
% Plot points from p2 on the image
scatter(p2x, p2y, 50, 'r', 'filled');
hold on;
% Plot points from p3 on the image
scatter(p3x, p3y, 50, 'r', 'filled');
hold on;

l1 = pflat(cross(p1(:,1), p1(:,2)));
rital(l1);
hold on;
l2 = cross(p2(:,1), p2(:,2));
rital(l2);
hold on;
l3 = cross(p3(:,1), p3(:,2));
rital(l3);
hold on;

% Computing intersection of the second and third line 
% (the lines obtained from the pairs p2 and p3)
intersect_p2_p3 = pflat(cross(l2,l3));
scatter(intersect_p2_p3(1), intersect_p2_p3(2), 50, 'r', 'filled');
hold on;

% Computing distance of first line (l1) and the intersection point
d = abs(dot(l1, intersect_p2_p3))/(sqrt(l1(1)^2 + l1(2)^2)) % d = 8.1950
