clc;
clearvars;
close all;

load("compEx3.mat");

% Plot the lines
figure;
hold on;

% Plotting lines through initial start and end points
plot ([startpoints(1,:); endpoints(1,:)] , ...
    [startpoints(2,:); endpoints(2,:)], 'b-');
axis equal;

% Projective transformations
H1 = [sqrt(3), -1, 1; 1, sqrt(3), 1; 0, 0, 2];
H2 = [1, -1, 1; 1, 1, 0; 0, 0, 1];
H3 = [1, 1, 0; 0, 2, 0; 0, 0, 1];
H4 = [sqrt(3), -1, 1; 1, sqrt(3), 1; 1/4, 1/2, 2];

% Adding homogeneous coordinate 1 as our third coordinate
startpoints = [startpoints; ones(1, size(startpoints, 2))];
endpoints = [endpoints; ones(1, size(endpoints, 2))];

% Computing transformations with our transform matrices
x1 = pflat(H1*startpoints);
y1 = pflat(H1*endpoints);
figure
hold on
% Plotting the new transformation
plot ([x1(1,:); y1(1,:)] , ...
    [x1(2,:); y1(2,:)], 'b-');
axis equal;

% Doing same steps for H2, H3, and H4 transformations
x2 = pflat(H2*startpoints);
y2 = pflat(H2*endpoints);
figure
hold on
plot([x2(1,:); y2(1,:)] , ...
    [x2(2,:); y2(2,:)], 'b-');
axis equal;

x3 = pflat(H3*startpoints);
y3 = pflat(H3*endpoints);
figure
hold on
plot([x3(1,:); y3(1,:)] , ...
    [x3(2,:); y3(2,:)], 'b-');
axis equal;

x4 = pflat(H4*startpoints);
y4 = pflat(H4*endpoints);
figure
hold on
plot([x4(1,:); y4(1,:)] , ...
    [x4(2,:); y4(2,:)], 'b-');
axis equal;
hold off;