clc;
clearvars;
close all;

load("compEx1.mat"); % loading compEx1.mat file

res2D = pflat(x2D); % applying pflat function to x2D
figure
plot(res2D(1,:), res2D(2,:), '.') % Plots a point at (res2D(1,i), res2D(2,i)) for each i.
axis equal % Makes sure that all axes have the same scale.

res3D = pflat(x3D); % applying pflat function to x3D
figure
plot3(res3D(1,:), res3D(2,:), res3D(3,:), '.') % Same as above but 3D
axis equal % Makes sure that all axes have the same scale.