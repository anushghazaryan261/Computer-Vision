clc;
clearvars;
close all;

load("compEx3.mat");

% Plot the lines
figure;
hold on;

% Plotting lines through initial start and end points
plot ([startpoints(1,:); endpoints(1,:)] , ...
    [startpoints(2,:); endpoints(2,:)], 'b-');
axis equal;

% Projective transformations
H1 = diag([1,2,1]);
H2 = [0,-1,-1;0,-1,0;-1,2,0];

% Adding homogeneous coordinate 1 as our third coordinate
startpoints = [startpoints; ones(1, size(startpoints, 2))];
endpoints = [endpoints; ones(1, size(endpoints, 2))];

%%
% task a
% Computing transformations with our transform matrices
x1 = pflat(H1*startpoints);
y1 = pflat(H1*endpoints);
figure
hold on
% Plotting the new transformation
plot ([x1(1,:); y1(1,:)] , ...
    [x1(2,:); y1(2,:)], 'b-');
axis equal;

% Doing same steps for H2, H3, and H4 transformations
x2 = pflat(H2*startpoints);
y2 = pflat(H2*endpoints);
figure
hold on
plot([x2(1,:); y2(1,:)] , ...
    [x2(2,:); y2(2,:)], 'b-');
axis equal;

%%
% task d
H = inv(H2)*H1;
[V, D] = eig(H);
