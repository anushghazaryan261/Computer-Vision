clc;
clearvars;
close all;

P = [2,0,1,0;1,-1,1,1;2,1,1,0];

v(:) = sign(det(P(:,1:3)))*P(3,1:3);
v(:) = v(:)./norm(v(:));