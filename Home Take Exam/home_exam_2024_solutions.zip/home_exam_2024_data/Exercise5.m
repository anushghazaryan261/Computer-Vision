clc;
clearvars;
close all;

P1 = [eye(3), zeros(3,1)];
% Define a matrix P2
P2 = [1,0,4,1; 0,1,2,0; 0,0,1,1];

% Compute the pseudo-inverse of A
P2_pseudo_inv = pinv(P2);

P3 = [-1,1,-2,1; -1,0,-1,0; 0,-2,0,0];
P3_times_P2_pseudo_inv = P3*P2_pseudo_inv;

e32x = [0,4,-2;-4,0,-2;2,2,0];

%%
% b - verify equations
% first let's compute the camera centers of each camera matrix
C1 = null(P1);
C2 = null(P2);
C3 = null(P3);

% compute epipoles 
e23 = P2*C3;
e13 = P1*C3;
e32 = P3*C2;
e12 = P1*C2;
e31 = P3*C1;
e21 = P2*C1;

% F12 and F13 are computed by hand in the report:
F12 = [0,-1,-2; 1,0,3; 0,1,2];
F13 = [0,0,0; 0,2,0; -1,0,-1];
F23 = e32x*P3_times_P2_pseudo_inv;

% Let's see if the equations are satisfied
disp(['e23''F12e13 = ', num2str(e23'*F12*e13)]);
disp(['e32''F13e12 = ', num2str(e32'*F13*e12)]);
disp(['e31''F23e21 = ', num2str(e31'*F23*e21)]);