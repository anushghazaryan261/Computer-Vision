clc;
clearvars;
close all;

% Given essential matrix E
E = [0,1,0;-1,0,0;0,0,0];

% Compute SVD of E
[U, S, V] = svd(E);

%%
% b - compute epipoles
% Extract the epipoles
right_epipole = V(:, end); % Right singular vector
left_epipole = U(:, end); % Left singular vector

% Normalize the epipoles
right_epipole = right_epipole / norm(right_epipole);
left_epipole = left_epipole / norm(left_epipole);

% Display the epipoles
fprintf('Right epipole: [%f, %f, %f]\n', right_epipole);
fprintf('Left epipole: [%f, %f, %f]\n', left_epipole);

%%
% c - get four possible camera pairs from E
W = [0, -1, 0; 1, 0, 0; 0, 0, 1];
u3 = U(:, end); %last column of U
% the four camera solutions
P21 = [U*W*V', u3];
P22 = [U*W*V', -u3];
P23 = [U*W'*V', u3];
P24 = [U*W'*V', -u3];
% P1 = [I 0]
P1 = [eye(3), zeros(3,1)];
