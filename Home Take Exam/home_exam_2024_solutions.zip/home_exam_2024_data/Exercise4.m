clc;
clearvars;
close all;

load("ex4.mat")
x(3,:) = 1;
X(4,:) = 1;
im = imread("ex4.jpg");

%%
[camera_matrix, inliers] = RANSAC(x, X, 5, 100);

%%
figure
imshow(im);
hold on;
plot(x(1,:), x(2,:), '*');
hold on;
xproj = pflat(camera_matrix*X);
plot(xproj(1,:), xproj(2,:), 'ro'); 
hold off;

% plotting the 3D points in 3D plot
figure
plot3(X(1,inliers), X(2,inliers), X(3,inliers), '.', 'MarkerSize', 2);
hold on;
plotcams({camera_matrix});
hold off;

%%
% Implement RANSAC
function [best_P, inliers] = RANSAC(points2D, points3D, threshold, iterations)
    best_P = [];
    bestInliersCount = 0;
    numPoints = size(points2D, 2);
    
    for i = 1:iterations
        % Randomly select minimal set of correspondences
        subsetIdx = randperm(numPoints, 6);
        subset2D = points2D(:, subsetIdx);
        subset3D = points3D(:, subsetIdx);

        % Apply DLT to compute camera matrix
        P = computeCameraMatrix(subset2D, subset3D);

        % Compute reprojection error for all points
        projectedPoints = pflat(P*points3D);
        projectedPoints = projectedPoints ./ repmat(projectedPoints(3, :), 3, 1);
        errors = sqrt(sum((points2D - projectedPoints).^2));

        % Step 4: Count inliers
        inlierIndices = find(errors < threshold);
        inliersCount = length(inlierIndices);
        
        % Step 5: Update bestH and bestInliersCount if needed
        if inliersCount > bestInliersCount
            bestInliersCount = inliersCount;
            best_P = P;
        end
    end
    % Refit bestH using all inliers
    projectedPoints = best_P * points3D;
    projectedPoints = projectedPoints ./ repmat(projectedPoints(3, :), 3, 1);
    errors = sqrt(sum((points2D - projectedPoints).^2));
    inliers = find(errors < threshold);
    allInliers2D = points2D(:, inliers);
    allInliers3D = points3D(:, inliers);
    best_P = computeCameraMatrix(allInliers2D, allInliers3D);
end

%%
function P = computeCameraMatrix(subset2D, subset3D)
    % constructing normalization matrices for the image
    mean1 = mean(subset2D, 2);
    std1 = std(subset2D, 0, 2);
    N = [1/std1(1), 0, -mean1(1)/std1(1);
      0, 1/std1(2), -mean1(2)/std1(2);
      0, 0, 1];

    subset2D = N*subset2D;
    n = size(subset3D, 2);

    % constructing the M matrices
    M = zeros(3*n, 12+n);
    for i = 1:n
       M(3*i-2,1:4) = subset3D(:,i)';
       M(3*i-1, 5:8) = subset3D(:,i)';
       M(3*i, 9:12) = subset3D(:,i)';
       M(3*i-2:3*i,12+i) = subset2D(:,i);
    end

    % Computes the singular value decomposition of M
    [U, S, V] = svd(M);
    %disp('The minimum singular value S:');
    %disp(min(diag(S))); % we see that the smallest eigenvalue is close to 0

    % setting up the camera matrix
    if V(end,end) < 0
        P = reshape(-V(1:12,end),4,3)';
    else
        P = reshape(V(1:12,end),4,3)';
    end
    % transform the camera matrix to the original (un-normalized) coordinate system
    P = N\P;
end