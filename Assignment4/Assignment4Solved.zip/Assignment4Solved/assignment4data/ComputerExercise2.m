clc;
clearvars;
close all;

load("compEx2data.mat"); % load data
im1 = imread("im1.jpg");
im2 = imread("im2.jpg");
% add homogeneous coordinate
x{1}(3,:) = 1;
x{2}(3,:) = 1;
% normalize by multiplying with inverse of K
x1n = K\x{1};
x2n = K\x{2};

%%
% Using RANSAC to estimate homography
% dividing the threshold by the focal length
[E, inliers] = essential_matrix_ransac(x1n, x2n, 5/K(2,2), 200); 
disp(['The number of inliers: ', num2str(length(inliers))]);
x1n = x1n(:, inliers);
x2n = x2n(:, inliers);
x{1} = x{1}(:,inliers);
x{2} = x{2}(:, inliers);

%%
[U,S,V] = svd(E);
if det(U*V')>0
    E = U*diag([1 1 0])* V';
else
    V = -V;
    E = U*diag([1 1 0])* V';
end
E = E./E(3, 3);
% run after executing comouter exercise 3
W = [0, -1, 0; 1, 0, 0; 0, 0, 1];
u3 = U(:, end); %last column of U
% the four camera solutions
P21 = [U*W*V', u3];
P22 = [U*W*V', -u3];
P23 = [U*W'*V', u3];
P24 = [U*W'*V', -u3];
% P1 = [I 0]
P1 = [eye(3), zeros(3,1)];

%%
% constructing 3D points
n = length(x1n);
X1 = zeros(4, n);
zero_mat = zeros(3,1);

% Loop through each point
for i = 1:n
    % Construct matrix M
    M = [P1, -x1n(:,i), zero_mat; P21, zero_mat, -x2n(:,i)];

    % Compute SVD of M
    [U, S, V] = svd(M);

    % Solution vector v is the column of V corresponding to the smallest singular value
    X1(:, i) = reshape(V(1:4,end),1,4);
end

% Reshape X to 3D points
X1 = X1(1:3, :) ./ repmat(X1(4, :), [3, 1]);
% add homogeneous coordinates
X1(4,:) = 1;

%%
% determining how many points are in front of the cameras
nX1P21 = 0;
for i = 1:n
    if(depth(P1, X1(:, i)) > 0 && depth(P21, X1(:, i)) > 0)
        nX1P21 = nX1P21 + 1;
    end
end

%%
% constructing 3D points
X2 = zeros(4, size(x{1}, 2));

% Loop through each point
for i = 1:size(x1n, 2)
    % Construct matrix M
    M = [P1, -x1n(:,i), zero_mat; P22, zero_mat, -x2n(:,i)];

    % Compute SVD of M
    [U, S, V] = svd(M);

    % Solution vector v is the column of V corresponding to the smallest singular value
    X2(:, i) = reshape(V(1:4,end),1,4)';
end

% Reshape X to 3D points
X2 = X2(1:3, :) ./ repmat(X2(4, :), [3, 1]);
% add homogeneous coordinates
X2(4,:) = 1;

%%
% determining how many points are in front of the cameras
nX2P22 = 0;
for i = 1:size(X2,2)
    if(depth(P1, X2(:, i)) > 0 && depth(P22, X2(:, i)) > 0)
        nX2P22 = nX2P22 + 1;
    end
end

%%
% constructing 3D points
X3 = zeros(4, size(x{1}, 2));

% Loop through each point
for i = 1:size(x1n, 2)
    % Construct matrix M
    M = [P1, -x1n(:,i), zero_mat; P23, zero_mat, -x2n(:,i)];

    % Compute SVD of M
    [U, S, V] = svd(M);

    % Solution vector v is the column of V corresponding to the smallest singular value
    X3(:, i) = reshape(V(1:4,end),1,4);
end

% Reshape X to 3D points
X3 = X3(1:3, :) ./ repmat(X3(4, :), [3, 1]);
% add homogeneous coordinates
X3(4,:) = 1;

%%
% determining how many points are in front of the cameras
nX3P23 = 0;
for i = 1:size(X3,2)
    if(depth(P1, X3(:, i)) > 0 && depth(P23, X3(:, i)) > 0)
        nX3P23 = nX3P23 + 1;
    end
end

%%
% constructing 3D points
X4 = zeros(4, size(x{1}, 2));

% Loop through each point
for i = 1:size(x1n, 2)
    % Construct matrix M
    M = [P1, -x1n(:,i), zero_mat; P24, zero_mat, -x2n(:,i)];

    % Compute SVD of M
    [U, S, V] = svd(M);

    % Solution vector v is the column of V corresponding to the smallest singular value
    X4(:, i) = reshape(V(1:4,end),1,4);
end

% Reshape X to 3D points
X4 = X4(1:3, :) ./ repmat(X4(4, :), [3, 1]);
% add homogeneous coordinates
X4(4,:) = 1;

%%
% determining how many points are in front of the cameras
nX4P24 = 0;
for i = 1:size(X4,2)
    if(depth(P1, X4(:, i)) > 0 && depth(P24, X4(:, i)) > 0)
        nX4P24 = nX4P24 + 1;
    end
end

%%
%Plotting the image, the projected points, and the image points in the same figure
figure
imshow(im2);
hold on;
% Plots a '*' at each point coordinate
plot(x{2}(1,:), x{2}(2,:), '*');
hold on;
% choose the best solution for P2 and X
if(nX1P21 > nX2P22 && nX1P21 > nX3P23 && nX1P21 > nX4P24)
    P2 = P21;
    X = X1;
elseif(nX2P22 > nX1P21 && nX2P22 > nX3P23 && nX2P22 > nX4P24)
    P2 = P22;
    X = X2;
elseif(nX3P23 > nX1P21 && nX3P23 > nX2P22 && nX3P23 > nX4P24)
    P2 = P23;
    X = X3;
elseif(nX4P24 > nX1P21 && nX4P24 > nX3P23 && nX4P24 > nX2P22)
    P2 = P24;
    X = X4;
end

%getting un-normalized camera matrices
P2 = K*P2;
P1 = K*P1;
xproj = pflat(P2*X);
% Plots a red ’o ’ at each visible point in xproj
plot(xproj(1,:), xproj(2,:), 'ro');
hold off;

%%
% plotting the 3D points in 3D plot
figure
plot3(X(1,:), X(2,:), X(3,:), '.', 'MarkerSize', 2);
hold on;
plotcams({P1, P2});
hold off;

%%
%reprojection errors with unnormalized camera matrices
rmsError = sqrt(sum((x{2} - xproj).^2));

figure
hist(rmsError, 100);
% Compute RMS error
rmsErrorValue = mean(sqrt(rmsError.^2));

disp(['RMS Error: ', num2str(rmsErrorValue)]);

%%
function [best_E, inliers] = essential_matrix_ransac(xA, xB, threshold, maxIterations)
    best_E = [];
    inliers = [];
    bestInliersCount = 0;
    numPoints = size(xA, 2);

    for iter = 1:maxIterations
        % Step 1: Randomly select minimal set of points
        subsetIdx = randperm(numPoints, 5);
        subsetA = xA(:, subsetIdx);
        subsetB = xB(:, subsetIdx);

        % Step 2: Compute homography matrix H
        E = fivepoint_solver(subsetA, subsetB);

        for Esol = 1:size(E, 2)
            % Count inliers
            inliersCount = 0;
            for i = 1:numPoints
                % get corresponding epipolar lines
                l1 = E{Esol}*xA(:,i);
                l1 = l1./sqrt(repmat(l1(1, :).^2 + l1(2, :).^2, [3 1]));

                l2 = E{Esol}'*xB(:,i);
                l2 = l2./sqrt(repmat(l2(1, :).^2 + l2(2, :).^2, [3 1]));

                % calculate distances of points to lines
                dist1 = abs(sum(l1.*xB(:, i)));
                dist2 = abs(sum(l2.*xA(:,i)));
                
                if dist1 < threshold && dist2 <threshold
                    inliersCount = inliersCount + 1;
                end
            end

            % Step 5: Update bestH and bestInliersCount if needed
            if inliersCount > bestInliersCount
                bestInliersCount = inliersCount;
                best_E = E{Esol};
            end
        end
    end

    % Refit bestH using all inliers
    
    % get corresponding epipolar lines
    l1 = best_E*xA;
    l1 = l1./sqrt(repmat(l1(1, :).^2 + l1(2, :).^2, [3 1]));

    l2 = best_E'*xB;
    l2 = l2./sqrt(repmat(l2(1, :).^2 + l2(2, :).^2, [3 1]));
                
    % calculate distances of points to lines
    dist1 = abs(sum(l1.*xB));
    dist2 = abs(sum(l2.*xA));
               
    inliers = find(dist1 < threshold & dist2 < threshold);
end