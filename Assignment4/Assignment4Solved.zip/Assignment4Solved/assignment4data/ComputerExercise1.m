clc;
clearvars;
close all;

% read images
A = imread("a.jpg");
B = imread("b.jpg");

%%
%947 SIFT features for A
[fA, dA] = vl_sift(single(rgb2gray(A)));
%865 SIFT featrues for B
[fB, dB] = vl_sift(single(rgb2gray(B)));
%204 matches
matches = vl_ubcmatch(dA, dB);
xA = [fA(1, matches(1,:)); fA(2, matches(1 ,:))]; 
xB = [fB(1, matches(2,:)); fB(2, matches(2 ,:))]; 

%%
% Using RANSAC to estimate homography
[bestH, inliers] = ransacHomography(xA, xB, 5, 100); 

%%
Htform = projective2d(bestH');
% Creates a transfomation that matlab can use for images .
% Note : MATLAB uses transposed transformations .
Rout = imref2d(size(A), [-200, 800], [-400, 600]);
% Sets the size and output bounds of the new image .
[Atransf] = imwarp(A, Htform, 'OutputView', Rout);
% Transforms the image
Idtform = projective2d(eye(3));
[Btransf] = imwarp(B, Idtform, 'OutputView', Rout);
% Creates a larger version of the second image
AB = Btransf;
AB(Btransf < Atransf) = Atransf(Btransf < Atransf);
% Writes both images in the new image . %( A somewhat hacky solution is needed
% since pixels outside the valid image area are not always zero ...)
imagesc(Rout.XWorldLimits, Rout.YWorldLimits, AB);
% Plots the new image with the correct axes

%%
function [bestH, inliers] = ransacHomography(xA, xB, threshold, maxIterations)
    bestH = [];
    bestInliersCount = 0;
    numPoints = size(xA, 2);
    xA(3,:) = 1;
    xB(3,:) = 1;

    for iter = 1:maxIterations
        % Step 1: Randomly select minimal set of points
        subsetIdx = randperm(numPoints, 4);
        subsetA = xA(:, subsetIdx);
        subsetB = xB(:, subsetIdx);

        % Step 2: Compute homography matrix H
        H = computeHomography(subsetA, subsetB);

        % Step 3: Compute reprojection error for each point
        projectedPoints = H * xA;
        projectedPoints = projectedPoints ./ repmat(projectedPoints(3, :), 3, 1);
        errors = sqrt(sum((xB - projectedPoints).^2));

        % Step 4: Count inliers
        inlierIndices = find(errors < threshold);
        inliersCount = length(inlierIndices);

        % Step 5: Update bestH and bestInliersCount if needed
        if inliersCount > bestInliersCount
            bestInliersCount = inliersCount;
            bestH = H;
        end
    end

    % Refit bestH using all inliers
    projectedPoints = bestH * xA;
    projectedPoints = projectedPoints ./ repmat(projectedPoints(3, :), 3, 1);
    errors = sqrt(sum((xB - projectedPoints).^2));
    inliers = find(errors < threshold);
    allInliersA = xA(:, inliers);
    allInliersB = xB(:, inliers);
    bestH = computeHomography(allInliersA, allInliersB);
end

function H = computeHomography(ptsA, ptsB)
    A = [];
    for i = 1:size(ptsA, 2)
        A = [A; -ptsA(1, i), -ptsA(2, i), -1, 0, 0, 0, ptsB(1, i)*ptsA(1, i), ptsB(1, i)*ptsA(2, i), ptsB(1, i);
              0, 0, 0, -ptsA(1, i), -ptsA(2, i), -1, ptsB(2, i)*ptsA(1, i), ptsB(2, i)*ptsA(2, i), ptsB(2, i);
              0, 0, 0, 0, 0, 0, 0, 0, 1]; % Adding a row of ones
    end

    [~, ~, V] = svd(A);
    H = reshape(V(:, end), 3, 3)';
end

