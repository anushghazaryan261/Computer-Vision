clc;
clearvars -except P1 P2 X x;
close all;

%%
% Takes two camera matrices and puts them in a cell .
P = {P1, P2};

%%
% Perform steepest descent optimization
max_iterations = 10;
[final_solution, objective_values] = steepest_descent(P, X, x, max_iterations);

% Plot objective value vs. iteration number
plot(1:max_iterations, objective_values, 'o-');
xlabel('Iteration Number'); 
ylabel('Objective Value');
title('Objective Value vs. Iteration Number');
grid on;

%%
% Define the steepest descent method
function [final_solution, objective_values] = steepest_descent(P, X, x, max_iterations)
    Psol = P;
    Xsol = X;
    objective_values = zeros(max_iterations, 1);
    errors = zeros(max_iterations,1);
    gamma_k = 0.00000000001;

    for k = 1:max_iterations
        % Evaluate the objective function with the updated solution
        [err, res] = ComputeReprojectionError(Psol, Xsol, x);
        errors(k) = err;
        objective_values(k) = sqrt(mean(errors.^2)/k);
        if(err > 1)
            gamma_k = gamma_k * 0.1;
        end

        % Compute reprojection error and Jacobian matrix
        [r, J] = LinearizeReprojErr(Psol, Xsol, x);
                
        % Update solution using steepest descent update rule
        delta_v = -gamma_k*J'*r;

        % Update solution for the next iteration
        [Psol, Xsol] = update_solution(delta_v, Psol, Xsol);        
        fprintf('Iteration %d: Objective Value = %f\n', k, objective_values(k));
    end

    final_solution = {Psol, Xsol};
end