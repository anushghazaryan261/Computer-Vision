function d = depth(P, X)
    A = P(1:3, 1:3);
    x = P*X;
    lambda = x(end,end);
    nA3 = norm(A(end,:));
    d = sign(det(A))*lambda\nA3;
end