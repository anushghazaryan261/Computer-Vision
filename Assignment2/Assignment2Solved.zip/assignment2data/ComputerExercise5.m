% run after executing exercise 3 and 4
% Initialize array to store 3D points
clc;
clearvars -except P1 P2 K1 K2 x1 x2 matches im1 im2 startind endind Xmodel;
close all;

%%
X = zeros(4, length(matches)); 
x1(3,:) = 1;
x2(3,:) = 1;
zero_mat = zeros(3,1);

% normalizing camera matrices
%P1 = inv(K1)*P1;
%P2 = inv(K2)*P2;

% Loop through each point
for i = 1:length(matches)
    % Construct matrix M

    %not diagonal M is 6x6
    %M = [P1, -x1(:,i), zero_mat; P2, zero_mat, -x2(:,i)];

    %normalizing the DLT equations
    M = [inv(K1)*P1, inv(K1)*(-x1(:,i)), zero_mat; inv(K2)*P2, zero_mat, inv(K2)*(-x2(:,i))];

    % Compute SVD of M
    [U, S, V] = svd(M);

    % Solution vector v is the column of V corresponding to the smallest singular value
    X(:, i) = reshape(V(1:4,end),1,4)';
end

% Reshape X to 3D points
X = X(1:3, :) ./ repmat(X(4, :), [3, 1]);
% add homogeneous coordinates
X(4,:) = 1;

%%
% Computes the projections
xproj1 = pflat(P1*X);
xproj2 = pflat(P2*X);

figure
imshow(im1);
hold on;
plot(xproj1(1, :), xproj1(2, :), 'b*');
hold on;
plot(x1(1, :), x1(2, :), 'ro');
hold off;

figure
imshow(im2);
hold on;
plot(xproj2(1, :), xproj2(2, :), 'b*');
hold on;
plot(x2(1, :), x2(2, :), 'ro');
hold off;

%%
% Finds the points with reprojection error less than 3 pixels in both images
good_points = (sqrt(sum((x1 - xproj1).^2)) < 3 & ...
    sqrt(sum((x2 - xproj2).^2)) < 3);

%%
P = {P1, P2};

% Plots the lines of the cube model (works only if all points are included)
figure
plot3 ([Xmodel(1 , startind ); Xmodel(1 , endind )] ,...
[Xmodel(2 , startind ); Xmodel(2 , endind )] ,...
[Xmodel(3 , startind ); Xmodel(3 , endind )] , 'b-' );
hold on;
plotcams(P);
hold on;
plot3(X(1, good_points), X(2, good_points), X(3, good_points), 'ro');
hold off;