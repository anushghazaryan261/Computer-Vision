clc;
clearvars;
close all;

load("compEx1data.mat") %loading data
%%
%plotting the reconstructions and cameras in one figure
figure
%plotting 3D points of the reconstruction
plot3(X(1,:), X(2,:), X(3,:), '.', 'MarkerSize', 2);
hold on;
%plotting the cameras in the same figure using plotcams.m
plotcams(P);
hold off;
axis equal;

%%
%taking the third image from the list
im = imread(imfiles{3});
%Plotting the image, the projected points, and the image points in the same figure
figure
imshow(im);
hold on;
% Determines which of the points are visible in image 3
visible = isfinite(x{3}(1,:));
% Plots a '*' at each point coordinate
plot(x{3}(1, visible), x{3}(2, visible), '*');
hold on;
% divide by the third coordinate
xproj = pflat(P{3}*X);
% Plots a red ’o ’ at each visible point in xproj
plot(xproj(1, visible), xproj(2, visible), 'ro');
hold off;

%%
% two projective transformations
T1 = [1,0,0,0; 0,4,0,0; 0,0,1,0; 1/10,1/10,0,1];
T2 = [1,0,0,0; 0,1,0,0; 0,0,1,0; 1/16,1/16,0,1];

% modifying 3D points
X1 = pflat(T1 * X);
X2 = pflat(T2 * X);

% modifying cameras
P1 = cell(1,9);
for row = 1:9
    P1{1,row} = P{row}*inv(T1);
end

P2 = cell(1,9);
for row = 1:9
    P2{1,row} = P{row}*inv(T2);
end

%%
figure
%plotting new 3D points of the first reconstruction
plot3(X1(1,:), X1(2,:), X1(3,:), '.', 'MarkerSize', 2);
hold on;
%plotting the cameras in the same figure using plotcams.m
plotcams(P1);
hold off;
axis equal;

%%
figure
%plotting new 3D points of the second reconstruction
plot3(X2(1,:), X2(2,:), X2(3,:), '.', 'MarkerSize', 2);
hold on;
%plotting the cameras in the same figure using plotcams.m
plotcams(P2);
hold off;
axis equal;

%%
%Plotting the image, the new projected points, and the image points in the same figure
figure
imshow(im); %taking the third image from the list
hold on;
% Plots a '*' at each point coordinate
plot(x{3}(1, visible), x{3}(2, visible), '*');
hold on;
% divide by the third coordinate
xproj1 = pflat(P1{3}*X1);
% Plots a red ’o ’ at each visible point in xproj
plot(xproj1(1, visible), xproj1(2, visible), 'ro');
hold off;

%%
%Plotting the image, the new projected points, and the image points in the same figure
figure
imshow(im); %taking the third image from the list
hold on;
% Plots a '*' at each point coordinate
plot(x{3}(1, visible), x{3}(2, visible), '*');
hold on;
% divide by the third coordinate
xproj2 = pflat(P2{3}*X2);
% Plots a red ’o ’ at each visible point in xproj
plot(xproj2(1, visible), xproj2(2, visible), 'ro');
hold off;
