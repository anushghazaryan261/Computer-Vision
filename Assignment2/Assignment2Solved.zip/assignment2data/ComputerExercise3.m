clc;
clearvars;
close all;

load("compEx3data.mat"); %load data

%%
% constructing normalization matrices for two images
mean1=mean(x{1}, 2);
std1=std(x{1}, 0, 2);
N1 = [1/std1(1), 0, -mean1(1)/std1(1);
      0, 1/std1(2), -mean1(2)/std1(2);
      0, 0, 1];

mean2=mean(x{2}, 2);
std2= std(x{2}, 0, 2);
N2 = [1/std2(1), 0, -mean2(1)/std2(1);
      0, 1/std2(2), -mean2(2)/std2(2);
      0, 0, 1];

x1 = N1*x{1};
x2 = N2*x{2};
%%
% Plotting the normalized points in a new figure
figure
plot(x1(1,:), x1(2,:), '.', 'MarkerSize', 9);
figure
plot(x2(1,:), x2(2,:), '.', 'MarkerSize', 9);

%%
n = size(Xmodel, 2); % number of correspondence pairs
Xmodel(4,:) = 1;

% constructing the M matrices
M1 = zeros(3*n, 12+n);
for i = 1:n
    M1(3*i-2,1:4) = Xmodel(:,i)';
    M1(3*i-1, 5:8) = Xmodel(:,i)';
    M1(3*i, 9:12) = Xmodel(:,i)';
    M1(3*i-2:3*i,12+i) = x1(:,i);
end
M2 = zeros(3*n, 12+n);
for i = 1:n
    M2(3*i-2,1:4) = Xmodel(:,i)';
    M2(3*i-1, 5:8) = Xmodel(:,i)';
    M2(3*i, 9:12) = Xmodel(:,i)';
    M2(3*i-2:3*i,12+i) = x2(:,i);
end

% Computes the singular value decomposition of M1 and M2
[U1, S1, V1] = svd(M1);
disp('The minimum singular value S1:');
disp(min(diag(S1))); % we see that the smallest eigenvalue is close to 0
[U2, S2, V2] = svd(M2);
disp('The minimum singular value S2:');
disp(min(diag(S2))); % we see that the smallest eigenvalue is close to 0

%%
% setting up the camera matrix
if V1(end,end) < 0
    P1 = reshape(-V1(1:12,end),4,3)';
else
    P1 = reshape(V1(1:12,end),4,3)';
end
% transform the camera matrix to the original (un-normalized) coordinate system
P1 = inv(N1)*P1;

if V2(end,end) < 0
    P2 = reshape(-V2(1:12,end),4,3)';
else
    P2 = reshape(V2(1:12,end),4,3)';
end
% transform the camera matrix to the original (un-normalized) coordinate system
P2 = inv(N2)*P2; 

%%
xproj1 = pflat(P1*Xmodel);
xproj2 = pflat(P2*Xmodel);

im1 = imread("cube1.JPG");
figure
imshow(im1);
hold on;
plot(xproj1(1, :), xproj1(2, :), 'y*', MarkerSize=10);
hold on;
plot(x{1}(1, :), x{1}(2, :), 'ro',MarkerSize=10);
hold off;

im2 = imread("cube2.JPG");
figure
imshow(im2);
hold on;
plot(xproj2(1, :), xproj2(2, :), 'y*', MarkerSize=10);
hold on;
plot(x{2}(1, :), x{2}(2, :), 'ro', MarkerSize=10);
hold off;

P{1} = P1; P{2} = P2;
figure
% Plots the lines of the cube model (works only if all points are included)
plot3([Xmodel(1, startind); Xmodel(1, endind)],...
    [Xmodel(2, startind ); Xmodel(2, endind)],...
    [Xmodel(3, startind ); Xmodel(3, endind)], 'b-' );
hold on;
plotcams(P);
hold off;

%%
%Compute the inner parameters of the first camera using rq.m
K1 = rq(P1);
K1 = K1./K1(3, 3)

% inner parameters for second camera
K2 = rq(P2);
K2 = K2./K2(3, 3)
