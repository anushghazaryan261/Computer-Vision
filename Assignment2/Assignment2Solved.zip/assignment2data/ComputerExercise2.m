clc;
clearvars;
close all;

load("compEx1data.mat") %loading data

% two projective transformations
T1 = [1,0,0,0; 0,4,0,0; 0,0,1,0; 1/10,1/10,0,1];
T2 = [1,0,0,0; 0,1,0,0; 0,0,1,0; 1/16,1/16,0,1];

% modifying cameras
P12 = P{2}*inv(T1);
P22 = P{2}*inv(T2);

% calculating K matrices and making sure that element K(3, 3) = 1
K1 = rq(P12);
K1 = K1./K1(3, 3)
K2 = rq(P22);
K2 = K2./K2(3, 3)
